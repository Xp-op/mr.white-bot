import webbrowser

webbrowser.open("https://media.discordapp.net/attachments/895644475739758602/923775183108583504/emoji.png")
