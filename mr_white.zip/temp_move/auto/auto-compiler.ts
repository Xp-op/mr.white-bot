import { AstNode } from "./auto-node";

export class Compiler {
    private nodes: Array<AstNode>;
    private p: number = -1;
    
}